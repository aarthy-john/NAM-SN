import numpy as np
from numpy import log
from sklearn.linear_model import LinearRegression


def higuchi_fd(signal, k_max=30):
    """
    Compute the Higuchi Fractal Dimension (HFD) of a time series signal.

    Args:
        signal (array-like): Input 1D signal.
        k_max (int): Maximum interval time (as per the paper, usually 30).

    Returns:
        float: The estimated Higuchi Fractal Dimension.
    """
    N = len(signal)
    Lk = np.zeros(k_max)

    for k in range(1, k_max + 1):
        Lmk = np.zeros(k)
        for m in range(k):
            # Construct k new time series x_m^k
            idx = np.arange(m, N, k)
            x_mk = signal[idx]

            # Compute average length L_m(k)
            Lm = np.sum(np.abs(np.diff(x_mk))) * (N - 1) / ((len(x_mk) * k))
            Lmk[m] = Lm

        # Average over all m for a given k
        Lk[k - 1] = np.mean(Lmk)

    # Prepare for linear regression in log-log scale
    log_k = log(1.0 / np.arange(1, k_max + 1))
    log_Lk = log(Lk)

    # Linear regression to get slope = fractal dimension
    reg = LinearRegression().fit(log_k.reshape(-1, 1), log_Lk)
    hfd = reg.coef_[0]

    return hfd


# # Example usage
# if __name__ == "__main__":
#     # Example signal (replace with EEG, ECG, etc.)
#     np.random.seed(42)
#     test_signal = np.cumsum(np.random.randn(2000))  # random walk signal
#     fd_value = higuchi_fd(test_signal, k_max=30)
#     print(f"Higuchi Fractal Dimension: {fd_value:.4f}")
