import numpy as np
from scipy.interpolate import CubicSpline
from scipy.ndimage import gaussian_filter1d
from scipy.signal import medfilt


def modified_emd(signal, sigma=1.0, alpha_lambda=0.05, w=11, lambda0=0.05, epsilon=1e-8, max_imfs=10):
    def find_extrema(s):
        dx = np.diff(s)
        maxima = np.where((dx[:-1] > 0) & (dx[1:] <= 0))[0] + 1
        minima = np.where((dx[:-1] < 0) & (dx[1:] >= 0))[0] + 1
        return maxima, minima

    def envelope(xs, points):
        if len(points) < 4:  # Not enough points for spline
            return np.interp(np.arange(len(xs)), points, xs[points])
        cs = CubicSpline(points, xs[points], bc_type='natural')
        return cs(np.arange(len(xs)))

    imfs = []
    residual = signal.copy()

    for _ in range(max_imfs):
        x = residual.copy()
        # h = None  # Ensure h is defined at the start of the loop
        while True:
            x_smooth = gaussian_filter1d(x, sigma)
            max_pts, min_pts = find_extrema(x_smooth)

            # If not enough extrema points, break the loop
            if len(max_pts) < 2 or len(min_pts) < 2:
                break

            # Calculate the envelope
            em = envelope(x, max_pts)
            el = envelope(x, min_pts)
            med_filtered = medfilt(x, kernel_size=w)

            alpha = alpha_lambda / (1 + np.std(x))
            a = (em + el) / 2 + alpha * med_filtered
            h = x - a  # h is the difference between x and the calculated average envelope

            # Check for extrema and zero-crossings
            num_extrema = len(find_extrema(h)[0]) + len(find_extrema(h)[1])
            zero_crossings = ((h[:-1] * h[1:]) < 0).sum()

            cond1 = abs(num_extrema - zero_crossings) <= 1

            # Adapt lambda based on variance
            lam = lambda0 * (np.var(x) + epsilon) / (np.var(h) + epsilon)
            tau = lam * (np.max(np.abs(h)) / (np.mean(np.abs(h)) + epsilon))
            cond2 = np.max(np.abs(a)) < tau * np.std(x)

            if cond1 and cond2:
                break  # If both conditions are satisfied, stop

            x = h  # Update x to the new h for the next iteration

        # Check if the IMF is repeating, and break if so
        if imfs and np.allclose(h, imfs[-1]):
            break
        h = 0
        imfs.append(h)  # Append the new IMF
        residual = residual - h  # Subtract the IMF from the residual

        if np.allclose(residual, 0):
            break  # If the residual is zero, stop the process

    imfs.append(residual)  # Append the residual as the last IMF
    return imfs[0]
