import numpy as np
from scipy.signal import gaussian
from scipy.fft import fft, ifft

def s_transform(signal_2d, fs=1000, fmin=1, fmax=200, num_freqs=256):
    """
    Apply S-transform on a 2D signal matrix (samples x channels).

    Args:
        signal_2d (ndarray): Input signal with shape (n_samples, n_channels)
        fs (float): Sampling frequency
        fmin (float): Minimum frequency of interest (Hz)
        fmax (float): Maximum frequency of interest (Hz)
        num_freqs (int): Number of frequency bins for S-transform

    Returns:
        s_transform_output (ndarray): Transformed signal with shape (n_samples, n_channels)
    """
    n_samples, n_channels = signal_2d.shape
    freqs = np.linspace(fmin, fmax, num_freqs)

    # Initialize output with same shape as input
    s_output = np.zeros((n_samples, n_channels))

    # Perform S-transform for each channel (column)
    for c in range(n_channels):
        signal = signal_2d[:, c]
        st_matrix = np.zeros((num_freqs, n_samples), dtype=complex)

        # Loop over frequencies
        for i, f in enumerate(freqs):
            # Gaussian window for frequency f
            window = gaussian(n_samples, std=n_samples / (f * fs))
            window_fft = fft(window)
            signal_fft = fft(signal)
            st_matrix[i, :] = ifft(signal_fft * window_fft)

        # You can choose feature extraction strategy
        # e.g., mean energy across frequencies for each time point
        s_output[:, c] = np.mean(np.abs(st_matrix), axis=0)

    return s_output
