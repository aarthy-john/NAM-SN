import cv2
import numpy as np

import Confusion_matrix
from other.root import *


def reshape_(data):
    # Convert the data to the appropriate data type (e.g., uint8)
    data_uint8 = (data * 255).astype(np.uint8)
    # Reshape and resize the data
    resized_data = np.zeros((len(data), 32, 32, 1), dtype=np.uint8)
    for i in range(len(data_uint8)):
        img = data_uint8[i].reshape(1, data_uint8.shape[1])  # Reshape each feature for processing
        img_resized = cv2.resize(img, (32, 32))  # Resize the feature to the desired shape
        img_resized_3d = np.repeat(img_resized[:, :, np.newaxis], 1, axis=2)  # Convert to 3 channels
        resized_data[i] = img_resized_3d  # Assign the resized image to the corresponding index in the new array
    return resized_data

def LeNet_(X_train, X_test, Y_train, Y_test):
    print('Lenet')
    from tensorflow.keras import layers, models
    from tensorflow.keras.utils import to_categorical
    # print("\n LeNet Model")
    x_train = reshape_(X_train)
    x_test = reshape_(X_test)
    input_shape_ = (32, 32, 1)
    y_train = to_categorical(Y_train)
    y_test = to_categorical(Y_test)
    # Build the LeNet-5 model
    model = models.Sequential()
    ln = len(np.unique(Y_train))

    # define the first set of CONV => ACTIVATION => POOL layers
    model.add(layers.Conv2D(6, (5, 5), activation='relu', input_shape=input_shape_))
    model.add(layers.MaxPooling2D((2, 2)))

    # define the second set of CONV => ACTIVATION => POOL layers
    model.add(layers.Conv2D(16, (5, 5), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))

    # define the first FC => ACTIVATION layers
    model.add(layers.Flatten())
    model.add(layers.Dense(120, activation='relu'))
    model.add(layers.Dense(84, activation='relu'))
    # define the second FC layer
    model.add(layers.Dense(ln, activation='softmax'))

    # Compile the model
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    # Train the model
    model.fit(x_train, y_train, epochs=1, batch_size=64, validation_split=0.2, verbose=0)
    y_pred = model.predict(x_test)
    y_pred = arraY_(y_pred.argmax(axis=-1), axis=5)
    return Confusion_matrix.confu_matrix(Y_test.reshape(-1, 1), y_pred), y_pred