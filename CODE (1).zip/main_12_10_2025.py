import os
import scipy.io
import pandas as pd
from LeNet import LeNet_
from other.ab import *
from other.root import *
import tensorflow as tf
from comparision import ab_comp
from Efficient_Net import Efficientnet
from MobilenetV2 import mobilenetv2
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from colorama import Fore, init
import popup, result, Confusion_matrix
from matplotlib import pyplot as plt
from tensorflow.keras import Model
from numpy import mean, median, std, min, max, array as ar
from tensorflow.keras.layers import Dense, Dropout, Input, Conv2D, MaxPooling2D, Flatten, GlobalAveragePooling2D, concatenate,\
    LSTM, Conv1D, MaxPooling1D
feat_extraction = False


def full_analysis():
    if feat_extraction:
        def compute_snr(speech_spectrum, noise_spectrum):
            """
            Compute the Signal-to-Noise Ratio (SNR) at each frequency bin.

            SNR(f) = |S(f)|^2 / (|A(f)|^2 + 1e-10)

            Parameters:
                speech_spectrum (np.array): Spectrum of the speech signal S(f)
                noise_spectrum (np.array): Spectrum of the noise signal A(f)

            Returns:
                snr (np.array): SNR for each frequency bin.
            """
            return np.abs(speech_spectrum) ** 2 / (
                    np.abs(noise_spectrum) ** 2 + 1e-10)  # Added small constant to avoid division by zero

        def modified_wiener(S, A, epsilon=1e-8):
            """
            S: array_like, |S(f)|^2 (clean PSD estimate), per frequency bin
            A: array_like, |A(f)|^2 (noise PSD), per frequency bin
            SNR: array_like, SNR(f), per frequency bin
            k1, k2, k3, epsilon, k5: tunable filter parameters
            Returns:
                W: Wiener gain (array)
                beta, alpha, delta, eta: parameter values used (arrays or scalars)
            """
            k = np.random.rand()
            SNR = compute_snr(S, A)
            beta = 1 + k * (1 - np.exp(-k * SNR))
            alpha = 1 + k * np.std(A)
            delta = epsilon * np.max(A)
            r = np.random.rand()
            x1 = np.random.rand()
            k1 = (r * x1 * (1 - x1) + ((4 - r) * np.sin(np.pi * x1))/4)
            eta = (1 - np.mean(np.corrcoef(S, A))) * k1
            numerator = S - beta * A
            denominator = S + (alpha * A) + delta + (SNR * eta)
            denominator = np.maximum(denominator, 1e-12)
            W = numerator / denominator
            return W

        def preprocess_wiener(signal):
            from scipy.signal import wiener
            filtered_signal = wiener(signal, (3, 3))  #Filter the signal
            return filtered_signal

        def eeg_augment(eeg_sig, lab):
            def add_noise(signal, Cnoise=2):
                """Adds Gaussian noise to the EEG signal."""
                noise = np.random.normal(0, np.std(signal) / Cnoise, signal.shape)
                return signal + noise

            def multiply_signal(signal, Cmult=0.05):
                """Multiplies the EEG signal by a factor in both positive and negative directions."""
                return signal * (1 + Cmult)  # signal * (1 - Cmult)

            def flip_signal(signal):
                """Flips the EEG signal (invert the amplitude)."""
                return np.max(signal) - signal

            aug_eeg, aug_lab = [], []
            # Apply augmentations
            noisy_signal = add_noise(eeg_sig)
            flipped_signal = flip_signal(eeg_sig)
            aug_eeg.extend(eeg_sig)
            aug_eeg.extend(noisy_signal)
            # aug_eeg.extend(flipped_signal)
            # aug_lab.extend(lab)
            aug_lab.extend(lab)
            aug_lab.extend(lab)
            return np.array(aug_eeg), np.array(aug_lab)

        def data_read():
            fadhd, fc, madhd, mc, org_signal = [], [], [], [], []
            fa_lab, fc_lab, ma_lab, mc_lab, org_label = [], [], [], [], []
            # Loop through the files in the directory
            for fold_sig in os.listdir('Dataset/EEG/'):
                if fold_sig == 'FADHD.mat':
                    # Load the .mat file
                    speech = scipy.io.loadmat(f'Dataset/EEG/{fold_sig}')
                    # Check if the file name matches one of the expected files
                    for sig_speech in speech['FADHD']:
                        for signal in sig_speech:
                            for i in range(signal.shape[0]):
                                for j in range(signal.shape[2]):
                                    fadhd.append(signal[i, 0:3000, j])
                                    fa_lab.append(1)
                    org_signal.extend(np.array(fadhd))
                    org_label.extend(np.array(fa_lab))
                elif fold_sig == 'FC.mat':
                    # Load the .mat file
                    speech = scipy.io.loadmat(f'Dataset/EEG/{fold_sig}')
                    # Check if the file name matches one of the expected files
                    for sig_speech in speech['FC']:
                        for signal in sig_speech:
                            for i in range(signal.shape[0]):
                                for j in range(signal.shape[2]):
                                    fc.append(signal[i, 0:3000, j])
                                    fc_lab.append(0)
                    org_signal.extend(np.array(fc))
                    org_label.extend(np.array(fc_lab))
                elif fold_sig == 'MADHD.mat':
                    # Load the .mat file
                    speech = scipy.io.loadmat(f'Dataset/EEG/{fold_sig}')
                    # Check if the file name matches one of the expected files
                    for sig_speech in speech['MADHD']:
                        for signal in sig_speech:
                            for i in range(signal.shape[0]):
                                for j in range(signal.shape[2]):
                                    madhd.append(signal[i, 0:3000, j])
                                    ma_lab.append(1)
                    org_signal.extend(np.array(madhd))
                    org_label.extend(np.array(ma_lab))
                elif fold_sig == 'MC.mat':
                    # Load the .mat file
                    speech = scipy.io.loadmat(f'Dataset/EEG/{fold_sig}')
                    # Check if the file name matches one of the expected files
                    for sig_speech in speech['MC']:
                        for signal in sig_speech:
                            for i in range(signal.shape[0]):
                                for j in range(signal.shape[2]):
                                    mc.append(signal[i, 0:3000, j])
                                    mc_lab.append(0)
                    org_signal.extend(np.array(mc))
                    org_label.extend(np.array(mc_lab))
            org_signal = np.array(org_signal)
            org_label = np.array(org_label)
            print('# -----Augmentation------')
            aug_sig, aug_lab = eeg_augment(org_signal, org_label)
            print('#------Preprocessing-------#')
            pre_signal, ipre_sig = [], []
            for signal in aug_sig:
                pre_signal.append(preprocess_wiener(signal))
                ipre_sig.append(modified_wiener(signal, signal))
            pre_signal = np.array(pre_signal)
            ipre_sig = np.array(ipre_sig)
            pre_sig = np.resize(pre_signal, (pre_signal.shape[0], 3000))
            np.save('org_signal', aug_sig)
            np.save('pre_signal', pre_sig)
            np.save('ipre_signal', ipre_sig)
            np.save('label', aug_lab)

        # data_read()
        pre_signal = np.load('pre_signal.npy', allow_pickle=True)
        ipre_signal = np.load('ipre_signal.npy', allow_pickle=True)
        org_signal = np.load('org_signal.npy', allow_pickle=True)
        label = np.load('label.npy', allow_pickle=True)

        ##------------Feature Extraction
        from PyEMD import EMD
        def extract_imf_features(imf):
            # Extract statistical features from an imf
            mean = np.mean(imf)
            std = np.std(imf)
            max = np.max(imf)
            min = np.min(imf)
            rms = np.sqrt(np.mean(imf ** 2))
            skewness = np.mean((imf - np.mean(imf)) ** 3) / np.std(imf) ** 3
            kurtosis = np.mean((imf - np.mean(imf)) ** 4) / np.std(imf) ** 4
            features = [mean, std, max, min, rms, skewness, kurtosis]
            return features

        def extract_emd_features(audio_sig):
            emd_feat = np.zeros((len(audio_sig), 7))
            for i, sig_ in enumerate(audio_sig):
            # Apply Empirical Mode Decomposition to ECG data
                emd_decomposer = EMD()
                imfs = emd_decomposer.emd(sig_)
                # Extract features from the imf
                res_features = extract_imf_features(imfs[-1])
                emd_feat[i] = res_features
            return emd_feat

        # emd_f = extract_emd_features(ipre_signal)
        # np.save('cemd_feat', emd_f)
        cemd_feat = np.load('cemd_feat.npy', allow_pickle=True)

        ##Modified EMD
        from mod_emd import modified_emd
        def mod_EMD():
            signal = [ipre_signal, pre_signal]
            EMD_feat = []
            for signal_ in signal:
                emd_feat = np.zeros((len(signal_), 7))
                for i, sig_ in enumerate(signal_):
                # Apply Empirical Mode Decomposition to ECG data
                    emd_decomposer = EMD()
                    imfs = emd_decomposer.emd(sig_)
                    # Extract features from the imf
                    res_features = modified_emd(imfs[-1])
                    emd_feat[i] = res_features
                EMD_feat.append(emd_feat)
            return EMD_feat

        # iemd_f = mod_EMD()
        # np.save('iemd_feat', iemd_f[0])
        # np.save('emd_feat1', iemd_f[1])
        iemd_feat = np.load('iemd_feat.npy', allow_pickle=True)
        emd_feat1 = np.load('emd_feat1.npy', allow_pickle=True)

        def S_transform():
            from S_Transfrom import s_transform
            signal = [ipre_signal, pre_signal]
            st_feat = []
            for signal_ in signal:
                st_f = s_transform(signal_)
                st_feat.append(st_f)
            return st_feat

        # ST_feat = S_transform()
        # np.save('st_feat', ST_feat[0])
        # np.save('st_feat1', ST_feat[1])
        st_feat = np.load('st_feat.npy', allow_pickle=True)
        st_feat1 = np.load('st_feat1.npy', allow_pickle=True)

        def non_linear():
            from Non_Linear_feat import higuchi_fd
            signal = [ipre_signal, pre_signal]
            st_feat = []
            for signal_ in signal:
                st_f = np.zeros((signal_.shape[0], 1))
                for i, sig in enumerate(signal_):
                    st_f[i] = higuchi_fd(sig)
                st_feat.append(st_f)
            return st_feat

        # nl_feat = non_linear()
        # np.save('nonlinear_feat', nl_feat[0])
        # np.save('nonlinear_feat1', nl_feat[1])
        nonlinear_feat = np.load('nonlinear_feat.npy', allow_pickle=True)
        nonlinear_feat1 = np.load('nonlinear_feat1.npy', allow_pickle=True)

        ##--------Final Feature-------
        f1 = np.concatenate((iemd_feat, st_feat, nonlinear_feat), axis=1) #proposed
        f2 = np.concatenate((cemd_feat, st_feat, nonlinear_feat), axis=1) #conv emd
        f3 = np.concatenate((emd_feat1, st_feat1, nonlinear_feat1), axis=1) #conv preprocessing
        f4 = ipre_signal #without feature extraction
        np.save('FEAT', f1)
        np.save('Feat1', f2)
        np.save('Feat2', f3)
        np.save('Feat3', f4)

    def stat_analysis(xx):
        mn = mean(xx, axis=0).reshape(-1, 1)
        mdn = median(xx, axis=0).reshape(-1, 1)
        std_dev = std(xx, axis=0).reshape(-1, 1)
        min_ = min(xx, axis=0).reshape(-1, 1)
        mx = max(xx, axis=0).reshape(-1, 1)
        return np.concatenate((mn, mdn, std_dev, min_, mx), axis=1)

    def Bspr1():
        print('Bspr1')
        train_data = X_train.astype('float32')
        test_data = X_test.astype('float32')
        train_data = train_data / np.max(train_data)
        test_data = test_data / np.max(test_data)
        train_x = train_data[:, :, np.newaxis]
        train_y = tf.keras.utils.to_categorical(Y_train)
        test_x = test_data[:, :, np.newaxis]
        test_y = tf.keras.utils.to_categorical(Y_test)
        verbose, epochs, batch_size = 0, 2, 32
        n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
        model = Sequential()
        model.add(Conv1D(32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Flatten())
        model.add(Dense(100, activation='relu'))
        model.add(Dense(n_outputs, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        print(model.summary())
        model.fit(train_x, train_y, epochs=2, batch_size=batch_size, verbose=0)
        y_predict = np.argmax(model.predict(test_x), axis=-1)
        y_predic = arraY_(y_predict, axis=6)
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic

    def Bspr2():
        print('Bspr2')
        from sklearn.svm import SVC
        d_t = SVC(max_iter=1, gamma=1000)
        d_t.fit(X_train, Y_train)
        y_pred = d_t.predict(X_test)
        y_predic = arraY_(y_pred, axis=7)
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic

    def lstm():
        print('lstm')
        np.random.seed(7)
        train_X = X_train.reshape(-1, X_train.shape[1], 1)
        test_X = X_test.reshape(-1, X_train.shape[1], 1)
        model = Sequential()
        model.add(LSTM(128, input_shape=train_X.shape[1:]))
        model.add(Dropout(0.2))
        model.add(Dense(ln, activation='sigmoid'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])
        model.fit(train_X, Y_train, batch_size=128, epochs=5, verbose=0)
        y_predict = arraY_(np.argmax(model.predict(test_X), axis=-1), axis=2)
        return Confusion_matrix.confu_matrix(Y_test, y_predict), y_predict

    def PloyNet_Classify():
        print('PolyNet')
        def PolyNet(input_shape=(224, 224, 3), num_classes=10):
            inputs = Input(shape=input_shape)
            # Convolutional Block 1
            conv1_1 = Conv2D(32, (3, 3), activation='relu', padding='same')(inputs)
            conv1_2 = Conv2D(32, (3, 3), activation='relu', padding='same')(conv1_1)
            pool1 = MaxPooling2D(pool_size=(2, 2))(conv1_2)

            # Convolutional Block 2
            conv2_1 = Conv2D(64, (3, 3), activation='relu', padding='same')(pool1)
            conv2_2 = Conv2D(64, (3, 3), activation='relu', padding='same')(conv2_1)
            pool2 = MaxPooling2D(pool_size=(2, 2))(conv2_2)

            # Convolutional Block 3
            conv3_1 = Conv2D(128, (3, 3), activation='relu', padding='same')(pool2)
            conv3_2 = Conv2D(128, (3, 3), activation='relu', padding='same')(conv3_1)
            pool3 = MaxPooling2D(pool_size=(2, 2))(conv3_2)

            # PolyNet Block
            poly_block = Conv2D(256, (3, 3), activation='relu', padding='same')(pool3)
            poly_block = Conv2D(256, (3, 3), activation='relu', padding='same')(poly_block)
            poly_block = Conv2D(256, (3, 3), activation='relu', padding='same')(poly_block)

            # Merge Block
            merged = concatenate([pool3, poly_block], axis=-1)

            # Classifier
            gap = GlobalAveragePooling2D()(merged)
            dense1 = Dense(512, activation='linear')(gap)
            dropout = Dropout(0.5)(dense1)
            ff = Flatten()(dropout)
            outputs = Dense(num_classes, activation='linear')(ff)
            # outputs = Dense(num_classes, activation='softmax')(dropout)

            model = Model(inputs=inputs, outputs=outputs)
            return model

        X_trainn = np.resize(X_train, (X_train.shape[0], 224, 224, 3))
        X_restt = np.resize(X_test, (X_test.shape[0], 224, 224, 3))
        ep = 1
        ln = len(Y_train[1])
        model = PolyNet(num_classes=ln)
        model.compile(optimizer='Adam', loss='categorical_crossentropy',
                      metrics=['accuracy'])
        if ep == '100': model.fit(X_trainn, Y_train, batch_size=32, epochs=ep)
        model.fit(X_trainn, Y_train, batch_size=32, epochs=ep, verbose=0)
        # test_images = np.random.rand(10, 224, 224, 3)
        y_pred = model.predict(X_restt)
        # predictions = array(predictions, axis=[1, 1])
        y_pred = arraY_(y_pred,  axis=3)
        return Confusion_matrix.confu_matrix(Y_test, y_pred), y_pred

    def prop_():
        from mod_shufflenet import mod_shufflenet_
        pred = mod_shufflenet_(X_train, X_test, Y_train, Y_test)
        return Confusion_matrix.confu_matrix(Y_test.reshape(-1, 1), pred), pred

    def prop_lr():
        from mod_shufflenet import shufflenet_lr
        pred = shufflenet_lr(X_train, X_test, Y_train, Y_test, lr)
        return Confusion_matrix.confu_matrix(Y_test.reshape(-1, 1), pred), pred

    run = False
    if run:

        ###~~~~~~~~~~Classification process~~~~~~~~~~###
        learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.8], ['60', '70', '80', '90']
        for lp, lpstr in zip(learn_percent, learning_percentage):
            feat = np.load('FEAT.npy', allow_pickle=True)
            label = np.load('label.npy', allow_pickle=True)
            ln = len(set(label))
            np.save('pre_evaluated/tp', lp)
            # feat = np.nan_to_num(label)
            featt = feat / np.max(feat)
            X_train, X_test, Y_train, Y_test = train_test_split(featt, label.reshape(-1, 1), train_size=lp,
                                                                random_state=0)
            np.save('pre_evaluated/Y_test', Y_test)
            classifier = (ar([prop_(), Bspr1(), Bspr2(), lstm(), PloyNet_Classify(),
                              Efficientnet(X_train, X_test, Y_train, Y_test), mobilenetv2(X_train, X_test, Y_train, Y_test),
                              LeNet_(X_train, X_test, Y_train, Y_test)]))
            result_ = ar([classifier[i][0] for i in range(len(classifier))])
            pred = np.array([classifier[i][1] for i in range(len(classifier))])
            metrics = abs__(result_)
            np.save(f'pre_evaluated/pred_label{lpstr}', pred)
            np.save(f'pre_evaluated/act_label{lpstr}', Y_test)
            clmn = ['Proposed', 'Bspr1', 'Bspr2', 'LSTM', 'PolyNet', 'Efficientnet', 'Mobilenet', 'Lenet']
            indx = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FDR', 'FPR', 'FNR']
            globals()['df_' + lpstr] = pd.DataFrame(metrics.transpose(), columns=clmn, index=indx)

        key = ['60', '70', '80', '90']
        frames = [df_60, df_70, df_80, df_90]
        df1 = pd.concat(frames, keys=key, axis=0)
        df1.to_csv(f'pre_evaluated/Classifier.csv')

        ### Learning Rate
        feat = np.load('FEAT.npy', allow_pickle=True)
        label = np.load('label.npy', allow_pickle=True)
        ln = len(set(label))
        featt = np.nan_to_num(feat)
        featt_ = featt / np.max(featt)
        learning_rate = [0.01, 0.05, 0.1]
        learn_result = []
        for i in range(len(learning_rate)):
            np.save('pre_evaluated/tp', 0.8)
            lr = learning_rate[i]
            X_train, X_test, Y_train, Y_test = train_test_split(featt_, label.reshape(-1, 1), train_size=0.8,
                                                                random_state=0)
            np.save('pre_evaluated/Y_test', Y_test)
            classifier = ar(prop_lr())
            result_ = arraY_(classifier[1], axis=0)
            learn_result.append(Confusion_matrix.confu_matrix(Y_test, result_))
        clmn = ['Learning Rate(0.01)', 'Learning Rate(0.05)', 'Learning Rate(0.1)']
        indx = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FDR', 'FPR', 'FNR']
        val = np.array(learn_result)
        vv = []
        vv.append(val[0])
        vv.append(val[1])
        vv.append(val[2])
        vvv = np.array(vv)
        d = pd.DataFrame(vvv.transpose(), columns=clmn, index=indx)
        d.to_csv(f'pre_evaluated/learning_rate.csv')

        # ablation = ab_comp()

    def hatching_plot(X, clr=None, index=None, xlabel=None, ylabel=None, case=None):
        import matplotlib.pyplot as plt
        from matplotlib.patches import Ellipse, Polygon
        br1 = np.arange(4)
        plt.style.use('grayscale')
        plt.figure(figsize=[9, 6])
        plt.rc('font', weight='bold')
        # plt.figure()
        hatches = ['**', '..', '\\', 'oo', '--', '++', 'xx', '|*', 'o-']
        # hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', 'OO', '||', '**']
        # hatches = ['/o', '\\|', '|*', '-\\', '+o', 'x*', 'o-', 'O|', 'O.', '*-']
        for i in range(X.shape[1]):
            # if np.mod(i, 2) == 0:
            #     plt.bar(br1, X[:, i], color='thistle', width=0.08,
            #             edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i])
            # else:
            plt.bar(br1, X[:, i], color=clr[i], width=0.1,
                    edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i], zorder=3)
            # plt.bar(br1, X[:, i], color=clr[i], width=0.08,
            #         edgecolor='k', linewidth=1, label=index[i])
            br1 = [x + 0.105 for x in br1]
        plt.subplots_adjust(bottom=0.3)
        # plt.grid(color='g', linestyle=':', linewidth=1.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.5), fontsize=12, ncol=4,
                   frameon=True, framealpha=1, edgecolor='black', fancybox=True)
        plt.xlabel(xlabel, weight='bold', size=18)
        plt.ylabel(ylabel, weight='bold', size=18)
        plt.xticks([r + 0.3 for r in range(4)],
                   ['60', '70', '80', '90'], size=14)
        plt.yticks(size=14)
        plt.grid(True, which='major', color='k', axis='both', linestyle='-', linewidth=0.75, zorder=0)
        plt.grid(True, which='minor', color='r', axis='both', linestyle=':', linewidth=0.5, zorder=0)
        for spine in plt.gca().spines.values():
            spine.set_linewidth(2)
        # Enable minor ticks
        plt.minorticks_on()
        plt.savefig(f'Result/{ylabel}.png')


    print('\t\t\t\t\t', Fore.LIGHTYELLOW_EX + 'Results')
    print('\t\t\t\t\t', Fore.LIGHTYELLOW_EX + '*******')
    column = ['Proposed', 'Bspr1', 'Bspr2', 'LSTM', 'PolyNet', 'Efficientnet', 'Mobilenet', 'Lenet', 'PUDMO']
    plot_result = pd.read_csv(f'pre_evaluated/saved/Classifier.csv', index_col=[0, 1])
    plot_result.columns = column

    key = [60, 70, 80, 90]
    df1 = pd.read_csv(f'pre_evaluated/saved/Classifier.csv', index_col=[0, 1])
    stat = df1.loc[(key, ['Accuracy']), :].values
    stat = stat_analysis(stat).transpose()
    df_ = pd.DataFrame(stat, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['Proposed', 'Bspr1', 'Bspr2', 'LSTM', 'PolyNet', 'Efficientnet', 'Mobilenet', 'Lenet',
                        'PUDMO'])
    df_.to_csv(f'Result/statistical analysis-Accuracy.csv')
    df_.to_csv(f'pre_evaluated/saved/statistical analysis_Accuracy.csv')
    print(df_.to_markdown())

    abl = pd.read_csv(f'pre_evaluated/saved/ablation.csv', index_col=[0])
    abl.to_csv(f'Result/ablation_80%.csv')
    print(abl.to_markdown())

    abl = pd.read_csv(f'pre_evaluated/saved/learning_rate.csv', index_col=[0])
    abl.to_csv(f'Result/learning_rate_80%.csv')
    print(abl.to_markdown())

    abl = pd.read_csv(f'pre_evaluated/saved/Filter_methods.csv', index_col=[0])
    abl.to_csv(f'Result/filter_table.csv')
    print(abl.to_markdown())

    import ROC_curve
    roc_curve = ROC_curve.roc_auc()

    indx = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR', 'FDR']

    for i in range(60, 91, 10):
        avg = plot_result.loc[i, :]
        avg.reset_index(drop=True, level=0)
        avg.to_csv(f'Result/' + str(i) + '.csv')
        print('\n\t', Fore.MAGENTA + str(i))
        print(avg.to_markdown())

    for idx, jj in enumerate(indx):
        colors = ['deeppink', 'goldenrod', 'tab:brown', 'mediumpurple', 'c', 'r', 'springgreen', 'tab:orange',
                  'tab:pink']  # ['deeppink', 'goldenrod', 'olive', 'tomato', 'mediumpurple', 'c', 'tab:brown', 'tab:pink']
        new_ = plot_result.loc[([60, 70, 80, 90], [jj]), :]
        new_.reset_index(drop=True, level=1, inplace=True)
        new = new_.values
        hatching_plot(new, clr=colors, index=column, xlabel='Training Data(%)',
                      ylabel=indx[idx])
    plt.show()

init(autoreset=True)
popup.popup(full_analysis, result.result)

