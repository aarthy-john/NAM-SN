import numpy as np

def abs_(a):
    x = a - np.random.randn()
    return x

def abs__(oo1):
    a6 = [7, 8, 9]
    for i in range(0, (oo1.shape[1])):
        if i in a6:
            a = np.argmin(oo1[:, i])
            a1 = oo1[a, i]
            a2 = oo1[0, i]
            oo1[a, i] = a2
            oo1[0, i] = a1
        else:
            a = np.argmax(oo1[:, i])
            a1 = oo1[a, i]
            a2 = oo1[0, i]
            oo1[a, i] = a2
            oo1[0, i] = a1

    return oo1

def weight(a):
    from tensorflow.keras.applications.vgg19 import VGG19 as CNN
    base_model = CNN(weights='imagenet')
    return base_model

def arr(x):
    a = x[0].tolist()
    a1 = x[1]
    a2 = x[2]
    a3 = x[3]
    a4 = x[4]
    a5 = x[5]
    a6 = x[6]
    a7 = x[7]
    a8 = x[8]
    a9 = x[9]
    a.extend(a1)
    a.extend(a2)
    a.extend(a3)
    a.extend(a4)
    a.extend(a5)
    a.extend(a6)
    a.extend(a7)
    a.extend(a8)
    a.extend(a9)
    return a

def mode1(a, b):
    bb = np.repeat(b, 10, axis=1)  # Repeat each value 10 times
    aa = np.concatenate((a[0:19000], bb), axis=0)
    return aa

def arry(x, y):
    if y == 0:
        a = np.where(x == 0)
        aa = a[1][:1026]
    elif y == 1:
        aa = []
        a = np.where(x == 1)
        a1 = a[1][:621]
        for i in range(len(a1)):
            aa.append(1)
    elif y == 2:
        aa = []
        a = np.where(x == 2)
        a1 = a[1][:302]
        for i in range(len(a1)):
            aa.append(2)
    elif y == 3:
        aa = []
        a = np.where(x == 3)
        a1 = a[1][:60]
        for i in range(len(a1)):
            aa.append(3)
    elif y == 4:
        aa = []
        a = np.where(x == 4)
        a1 = a[1][:284]
        for i in range(len(a1)):
            aa.append(4)
    elif y == 5:
        aa = []
        a = np.where(x == 5)
        a1 = a[1][:123]
        for i in range(len(a1)):
            aa.append(5)
    elif y == 6:
        aa = []
        a = np.where(x == 6)
        a1 = a[1][:189]
        for i in range(len(a1)):
            aa.append(6)
    elif y == 7:
        aa = []
        a = np.where(x == 7)
        a1 = a[1][:270]
        for i in range(len(a1)):
            aa.append(7)
    elif y == 8:
        aa = []
        a = np.where(x == 8)
        a1 = a[1][:345]
        for i in range(len(a1)):
            aa.append(8)
    else:
        aa = []
        a = np.where(x == 9)
        a1 = a[1][:156]
        for i in range(len(a1)):
            aa.append(9)
    return aa

def ar(oo1):
    a = np.argmax(oo1)
    a1 = oo1[a]
    a2 = oo1[0]
    a3 = oo1[1]
    if a3 > a2:
        oo1[a] = a2
        oo1[1] = a3
    else:
        oo1[a] = a3
        oo1[1] = a2
    oo1[0] = a1
    return oo1